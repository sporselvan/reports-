<?php
// echo var_dump($data);
?>

<html>

<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
    
        .form-control{
         display:block;
		 width:30%;
	 }
     input{
         display:block;
     }
    
</style>

<script>
    
       function getData(){
                           var id = $(".identy").val();
                           var name = $(".fname").val();
						   var surname = $(".sname").val();
						   var contact = $(".contactDetails").val();
						   var password = $(".pass").val();
						   var day = $(".days").val();
						   var month = $(".months").val();
						   var year = $(".years").val();
						   var dob = year+"-"+month+"-"+day;
                           var gender = document.querySelector('input[name="gender"]:checked').value;

                           console.log(name,surname,contact,password,dob,gender);
                           console.log(id,name,surname,contact,password,dob,gender);
                           update(id,name,surname,contact,password,dob,gender);
  
           
       }    

       function update(id,name,surname,contact,password,dob,gender){
        console.log("from update function",id,name,surname,contact,password,dob,gender);
           
                       $.ajax({
                             url: "<?php echo base_url()?>index.php/welcome/editData ",
					         method: 'POST',
					         data:{id:id,firstname:name,surname:surname,contact:contact,password:password,dob:dob,gender:gender},
					         success:(data,status)=>{
                                if(status="success"){
                                    //  alert(`user ${id} updated successfully`);
									 getRecord();
							  }
					   }
				   });
       }

   

</script>


</head>

<body>
    <div class="container">
        
    
    <?php
    
     $i = 1;
    //  echo $id;
     foreach($data as $row){
         $str = $row->dob;
        
         $arr = explode("-",$str);
         $year = $arr[0];
         $month = $arr[1];
         $day = $arr[2];
         
        //  echo "<h3> Update user info </h3> "; 
        
         echo "<input type='text' name='id'  class='form-control'  id='identy' value=".$row->id.">";
         
         echo "<input type='text' name='firstname'  class='form-control' id='fname' value=".$row->firstname.">";
        
         echo "<input type='text' name='surname' class='form-control'  id='sname' value=".$row->surname.">";
        
         echo "<input type='text' name='contact' class='form-control' id='contactDetails' value=".$row->contact.">";
        
         echo "<input type='password' name='password' class='form-control' id='pass' value=".$row->password.">";
         echo '
         <div class="wrapper"> 
              <span id="eye" class="glyphicon glyphicon-eye-close"></span><br><br>
                  <p class="passWarn"  id="passWarn" > </p>
              <input type="button" id="generateKey" value="Generate password" class="btn btn-success"><br><br>
         </div>';

         echo "<label> Date of birth </label> ";
         $days=array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);

         echo '<select name="day" class="form-control"  id="days">';
         foreach($days as $day){	  
             echo   "<option >$day</option>";
         }
          echo' </select>';

          echo "<select name='month' class='form-control' id='month'>
           <option value='01' >Jan</option>
           <option value='02'>Feb</option>
           <option value='03'>Mar</option>
           <option value='04'>Apr</option>
           <option value='05'>May</option>
           <option value='06'>June</option>
           <option value='07'>Jul</option>
           <option value='08'>Aug</option>
           <option value='09'>Sep</option>
           <option value='10'>Oct</option>
           <option value='11'>Nov</option>
           <option value='12'>Dec</option>
          </select>";


          $arr=array(1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2009,2010,2011,2012,2013,2014,2015);
          echo '<select name="year" id="years" class="form-control" onchange="validAge()" id="year">';
          foreach($arr as $val){
              echo "<option >$val</option>";
           }
           echo '</select> <br><br>';

        //  echo "<input type='text' name='year' class='form-control' id='years' value=".$year.">";
        //  echo "<input type='text' name='month'  class='form-control' id='months'' value=".$month.">";
        //  echo "<input type='text' name='day' class='form-control'  id='days' value=".$day.">";
        //  echo "<label> Gender </label> ";
        //  echo "<input type='text' id='genders'  class='form-control' name='gender' value=".$row->gender."> <br>";
        echo '<input type="radio" name="gender" id="male"  value="Male" > 
        <label for="male">Male</label>
        <input type="radio" name="gender" id="female" value="Female" >
        <label for="female" >Female</label> <br><br>';

         echo "<button class ='btn btn-success' type='button' onclick='getData()' name='update' data-dismiss='modal' value='update' > Update </button>";
         
     }
     
  ?>
  
   
    

    </div>



</body>

</html>
