<?php
  
  class Crudmodel extends CI_model{
          
    
       public function getallrecords(){
          //   echo "from model call";
            $query = $this ->db-> get('info');
            return $query -> result();
       }

       public function insertdata($data){
            
          $this -> db -> insert('info',$data);
          return true;
       }

       public function displayRecordsById($id){

           $query = $this -> db-> query("select * from info where id=$id");
           return $query -> result();
           
       }

       public function updatenow($firstname,$surname,$contact,$password,$dob,$gender,$id){
          $query = $this -> db -> query("update info set firstname='$firstname',surname='$surname',contact='$contact',password='$password',dob='$dob',gender='$gender' where id=$id");
          return true;
       }

       public function deletenow($id){ 
             $this -> db -> query("delete from info where id=$id");
             return true;

       }

  }

?>