<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
		
	}

	
	public function __construct()
	{
	parent::__construct();   
	$this->load->database();
	$this->load->model('Crudmodel');
	}

	
	public function showRecords(){
		
		 $result['data']  = $this->Crudmodel->getallrecords();
		 $this->load->view('welcome_message',$result);
	}

	public function createdata(){
               
			  $data['firstname'] = $this->input->post('firstname');
			  $data['surname'] = $this->input->post('surname');
			  $data['contact'] = $this->input->post('contact');
			  $pass = $this->input->post('password');
			  $data['password'] = md5($pass);
			  $data['dob']= $this -> input -> post('dob');
			  $data['gender'] = $this -> input ->post('gender');
              $response = $this -> Crudmodel -> insertdata($data);

	}

    public function updatedata(){
		 
		 $id = $this -> input -> post('id');
         $res['data'] = $this -> Crudmodel -> displayRecordsById($id); 
	     $this -> load -> view('updateview',$res);
		
	}

	public function editData(){
		
		    
              $id =  $this->input->post('id');
		      $firstname = $this->input->post('firstname');
			  $surname = $this->input->post('surname');
			  $contact = $this->input->post('contact');
			  $password = $this->input->post('password');
			  $dob= $this->input->post('dob');
			
			  $gender = $this -> input ->post('gender');
              $res = $this -> Crudmodel -> updatenow($firstname,$surname,$contact,$password,$dob,$gender,$id);
	}


	public function deletedata(){
		   echo "delete method";
		   $id = $this -> input -> post('id');
		   echo $id;
		   $res = $this -> Crudmodel -> deletenow($id);
		}
		   
	}


