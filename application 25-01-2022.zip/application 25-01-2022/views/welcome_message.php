<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	.form-control{
		width:10%;
		display:inline;
	}
	#contact,#password{
		width:20%
	}
	#fname,#sname{
		width:20%;
	}
	#contactDetails,#pass{
		width:40%
	}
	#day,#month,#year{
		width:6.4%
	}
	#days,#months,#years{
		width:13.5%
	}
	.passWarn{
		width:20%
	}
	.dltAlert{
		padding-left:10%;
		padding-top:5%;
		padding-bottom:5%;
	}
	

	
	</style>

	<script>

       $(document).ready(()=>{
					   console.log("document is ready");
					   getRecord();
	   })
       

	   $(document).on('click','#submit',function(){

		var name = $("#firstname").val();
						   var surname = $("#surname").val();
						   var contact = $("#contact").val();
						   var password = $("#password").val();
						   var day = $("#day").val();
						   var month = $("#month").val();
						   var year = $("#year").val();
						   var dob = year+"-"+month+"-"+day;
                           var gender = document.querySelector('input[name="gender"]:checked').value;

						   var d = {firstname:name,surname:surname,contact:contact,password:password,dob:dob,gender:gender};
					        $.ajax({	
							  url: "<?php echo base_url()?>index.php/welcome/createdata" ,
							  method: 'POST',
							  data: {firstname:name,surname:surname,contact:contact,password:password,dob:dob,gender:gender} ,
							  success:(data,status)=>{
                                  if(status == "success"){
									//   alert("posted");
									  getRecord();
								  }
								  
							  }
						 });
        });




	   $(document).on('click','#eye',function(){

		let inputType =  $("#password").attr('type');
					//    alert(inputType);
					   if(inputType == "password"){
						   $('#password').attr('type','text');
						   $('#eye').attr('class','glyphicon glyphicon-eye-open');
					   }
					   if(inputType == "text"){
						   $('#password').attr('type','password');
						   $('#eye').attr('class','glyphicon glyphicon-eye-close');
					   }
        });


	   $(document).on('click','#generateKey',function(){

		   		let str1 = Math.random().toString(16).toUpperCase().substring(2);
                    let str2 = Math.random().toString(16).substring(2);
					  let num = Math.floor((Math.random() * 4) + 1);
				    let specialChar = ['!','@','$','%','&','~','-'];
                    let text = str1+specialChar[num]+str2.slice(5);
                    $("#password").val(text);
					   validateKey();
         });

		function getRecord(){

			let http = new XMLHttpRequest();
		    http.onreadystatechange = function() {
                     if (this.readyState == 4 && this.status == 200) {
                     document.getElementById("container").innerHTML = http.responseText;
					
            }
          };

		http.open('GET',"http://localhost/crudajax/index.php/welcome/showRecords");
		http.send();
		}

		function updateUser(id){
               console.log(id);
			   $.ajax({
                       url: "<?php echo base_url()?>index.php/Welcome/updatedata",
					   method: 'POST',
					   data: {id:id},
					   success:(data)=>{
									console.log(typeof data);
									 $('.modal-body').html(data);
									 $("#myModal").modal('show');
									//  getRecord();
							  }
				   });   
		}

	
		function dltUser(id){
                      console.log(id);
					  $.ajax({
                       url: "<?php echo base_url()?>index.php/welcome/deletedata",
					   method: 'POST',
					   data: {id:id},
					   success:(data,stat)=>{
                              if(stat="success"){
                                    //  alert(`user ${id} Deleted successfully`);
									 getRecord();
									 $("#deleteModal").modal('hide');
							  }
					   }
				   });	
		}

		function removeUser(id){
			$("#deleteModal").modal('show');
			let rmBtn = `<button type='click' class='btn btn-danger' onclick="dltUser('${id}')"> Yes </button>
			<button type="button" class="btn btn-default" data-dismiss="modal">No</button>`;
			console.log(typeof rmBtn);
			$(".modal-footer").html(rmBtn);

		}

		function validate(){
		let x = document.getElementById("firstname");
		let value = x.value;
		let pattern = /\d/;
		let result = value.match(/\d/);
		if(result == true){
             $(".error").text("Enter valid input !");	
		}else{
			$(".error").text("");
			
		}
	  }

	function validAge(){
		console.log("touched");
		let ele = document.getElementById("year");
		let value =parseInt(ele.value) ;

		if(value >= 2009){
			console.log("error");
			$(".age").text("Age should be greater than 13 ! ");
		
		}else{
			$(".age").text("");
		}
	}

	function validateKey(){
		
		console.log("c");
           
		let passkey = $('#password').val();
		let passLength =passkey.length;
		
		if(passLength < 8){
			$("#passWarn").css("color","red").text("password must be contain atleast 8 characters");
		}
		else if(  ! passkey.match(/\d+/)){
			$("#passWarn").css("color","red").text("password must be contain atleast one numeric");
		}
		else if( ! passkey.match(/[A-Z]+/)){
            $("#passWarn").css("color","red").text("password must be contain atleast one Capital letter");
		}
		else if( ! passkey.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/)){
            $("#passWarn").css("color","red").text("password must be contain atleast one special letter");
		}
		else if( passLength >= 8 && passkey.match(/\d+/) && passkey.match(/[A-Z]+/) && passkey.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/) ){
            $("#passWarn").css("color","green").text("Valid password");
		}
	}

	
    </script>

</head>
<body>

<div id="container" class="container-fluid">
 <div class="container-fluid">

	<h1> Sign up </h1>

    <form >

	<input type="text" name="firstname" id="firstname" class="form-control" onkeyup="validate()" placeholder="First name" > 
	        
	
	<input type="text" name="surname" id="surname" class="form-control" placeholder="Surname" ><br><br>
	<p style="color:red;" class="error"> </p>
	
	<input type="text" name="contact" id="contact" class="form-control" placeholder="Mobile number or Email Address" ><br><br>
	
	<div class="wrapper">
	     <input type="password" name="password" id="password" class="form-control" onkeyup="validateKey()" placeholder="New password" > 
	     <span id="eye" class="glyphicon glyphicon-eye-close"></span><br><br>
             <p class="passWarn"  id="passWarn" > </p>
		 <input type="button" id="generateKey" value="Generate password" class='btn btn-success'><br><br>
	</div>

	<label>Date of birth</label><br>
     <?php 
    
	  $days=array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);

      echo '<select name="day" class="form-control"  id="day">';
	  foreach($days as $day){	  
          echo   "<option >$day</option>";
	  }
       echo' </select>';
	 
	 ?>

	<select name="month" class="form-control" id="month">
		 <option value="01" >Jan</option>
	 	 <option value="02">Feb</option>
		  <option value="03">Mar</option>
		  <option value="04">Apr</option>
		  <option value="05">May</option>
		  <option value="06">June</option>
		  <option value="07">Jul</option>
		  <option value="08">Aug</option>
		  <option value="09">Sep</option>
		  <option value="10">Oct</option>
		  <option value="11">Nov</option>
		  <option value="12">Dec</option>
	</select>

	<?php
           $arr=array(1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2009,2010,2011,2012,2013,2014,2015);
		   echo '<select name="year" id="year" class="form-control" onchange="validAge()" id="year">';
		   foreach($arr as $val){
               echo "<option >$val</option>";
			}
			echo '</select> <br><br>';
			?>

	<p  style="color:red;" class="age"> </p>

   <label>Gender</label><br>
   
   <input type="radio" name="gender"   value="Male" > 
   <label for="male">Male</label>
   <input type="radio" name="gender" value="Female" >
   <label for="female" >Female</label> <br><br>
   
   <button type="button" class="btn btn-success"  id="submit"> Sign Up</button> 
   <button type="button" class="btn btn-info" onclick="getRecord()" > Show records</button> <br><br>
   <p id="response"> </p>
   </form>

   <table class="table table-hover" >
     <tr >
     <th>Sr No</th>
     <th>First_name</th>
     <th>Sur name</th>
	 <th>Contact</th>
     <th>Password</th>
     <th>Date of Birth</th>
     <th>Gender</th>
     <th>Action</th>
	 
   </tr>

  <?php


  $i=1;
  
  if(isset($data)){
	foreach($data as $row )
	{
	$id = $row->id;
	echo "<tr>";
	echo "<td>$row->id </td>";
	echo "<td>$row->firstname</td>";
	echo "<td>$row->surname</td>";
	echo "<td>$row->contact</td>";
	echo "<td>$row->password</td>";
	echo "<td>$row->dob</td>";
	echo "<td>$row->gender</td>";
	echo "<td><button type='button' class='btn btn-info'  onclick='updateUser($row->id)' >Edit</button> 
	<button type='click' class='btn btn-danger' id='delete' onclick='removeUser($row->id)'> Delete </button>
	<td>";
	// echo "<td>  </td> ";
	echo "</tr>";
	$i++;
  }
  
  
  }
   ?>
 </table>

 
				<div id="myModal" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<h4 class="modal-title">Update sheet</h4>
							</div>
							<div class="modal-body">

						

							</div>
						
						</div>
					</div>

				</div>

				<div id="deleteModal" class="modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<h4 class="modal-title">Delete user</h4>
							</div>
							<div class="modal-bod">
								<p class="dltAlert" >Are you sure want to delete this user ? </p>
							
								
							</div>
							<div class="modal-footer">
                               
                            </div> 
						
						</div>
					</div>

				</div>

			

  </div>
</div>
   

</body>
</html>